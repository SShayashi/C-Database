gcc -c test-datamanip.c
gcc  -o test  test-datamanip.o file.o datadef.o datamanip.o -lreadline -lcurses
./test